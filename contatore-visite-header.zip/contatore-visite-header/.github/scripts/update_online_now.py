"""Fetch an approximate "online now" visitor count from GoatCounter and write
static/online-now.json.

GoatCounter non ha un vero contatore "in tempo reale": questa è un'approssimazione
onesta, calcolata come numero di visitatori unici negli ultimi WINDOW_MINUTES minuti
(endpoint /api/v0/stats/total). Il file viene aggiornato ogni pochi minuti da una
GitHub Action schedulata (.github/workflows/update-online-now.yml): il numero mostrato
sul sito è quindi "quasi in tempo reale", non istantaneo (dipende dalla frequenza reale
di esecuzione della action, che GitHub può ritardare rispetto alla schedulazione).

Requires la stessa variabile d'ambiente GC_TOKEN già usata da update_countries.py e
update_ascolti.py, fornita dal repository secret GOATCOUNTER_API_TOKEN (nessuna nuova
credenziale). Se il token non è impostato, lo script esce senza modificare nulla, così
l'azione non fallisce.
"""
import json
import os
import sys
import datetime
import urllib.request
import urllib.parse

GOATCOUNTER_SITE = "https://mediaresenzaconfini.goatcounter.com"
WINDOW_MINUTES = 10  # finestra usata come approssimazione di "adesso"
OUTPUT_PATH = "static/online-now.json"


def fetch_total(token, start_iso, end_iso):
    qs = urllib.parse.urlencode({"start": start_iso, "end": end_iso})
    req = urllib.request.Request(
        GOATCOUNTER_SITE + "/api/v0/stats/total?" + qs,
        headers={
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.load(resp)


def main():
    token = os.environ.get("GC_TOKEN", "").strip()
    if not token:
        print("Nessun GOATCOUNTER_API_TOKEN impostato: salto l'aggiornamento.")
        return 0

    now = datetime.datetime.utcnow()
    start = now - datetime.timedelta(minutes=WINDOW_MINUTES)
    start_iso = start.strftime("%Y-%m-%dT%H:%M:%SZ")
    end_iso = now.strftime("%Y-%m-%dT%H:%M:%SZ")

    data = fetch_total(token, start_iso, end_iso)
    online = data.get("total_unique")
    if online is None:
        online = data.get("total_unique_utc", 0)

    out = {
        "generated_at": end_iso,
        "window_minutes": WINDOW_MINUTES,
        "online": online,
    }

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
        f.write("\n")

    print("Scritto " + OUTPUT_PATH + ":", out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
